import { FileStorage } from "./file-storage";

export const storage = new FileStorage();
